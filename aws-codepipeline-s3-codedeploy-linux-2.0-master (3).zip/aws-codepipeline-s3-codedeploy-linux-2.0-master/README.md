# AWS-CodePipeline-S3-AWS-CodeDeploy-Linux

Use this sample when creating a simple pipeline in AWS CodePipeline while following the Simple Pipeline Walkthrough tutorial.
